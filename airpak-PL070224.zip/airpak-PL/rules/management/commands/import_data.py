import json
from django.core.management.base import BaseCommand
from rules.models import DictionaryVariable, VariableScorecard

class Command(BaseCommand):
    help = 'Import master data for DictionaryVariable and VariableScorecard models'

    def handle(self, *args, **options):
        # Load data from JSON files
        with open('static/Master-json-data/rules_dictionaryvariable.json') as f:
            dictionary_variable_data = json.load(f)

        with open('static/Master-json-data/rules_variablescorecard.json') as f:
            variable_scorecard_data = json.load(f)

        # Import data for DictionaryVariable model
        for data in dictionary_variable_data:
            DictionaryVariable.objects.get_or_create(**data)
            self.stdout.write(self.style.SUCCESS(f'Successfully imported DictionaryVariable data with ID {data["id"]}'))

        # Import data for VariableScorecard model
        for data in variable_scorecard_data:
            VariableScorecard.objects.get_or_create(**data)
            self.stdout.write(self.style.SUCCESS(f'Successfully imported VariableScorecard data with ID {data["id"]}'))

        self.stdout.write(self.style.SUCCESS('Data import completed'))
