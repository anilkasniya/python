from django.contrib import admin
from rules.models import DictionaryVariable, VariableScorecard, ApiResonse, TotalRequest

@admin.register(DictionaryVariable)
class VariableTypeAdmin(admin.ModelAdmin):
    list_display = ('variable_name', 'variable_display_name','variable_source', 'variable_value')
    search_fields = ('variable_name',)

# @admin.register(VariableScorecard)
class VariableScoreAdmin(admin.ModelAdmin):
    list_display = ('variable_name', 'variable_display_name','bucket_number', 'bucket_label')
    # search_fields = ('variable_name',)
admin.site.register(VariableScorecard, VariableScoreAdmin)
class ApiResonseAdmin(admin.ModelAdmin):
    list_display = ('user', 'response','created_date')
# Associate the custom admin class with the model
admin.site.register(ApiResonse, ApiResonseAdmin)

class TotalRequestAdmin(admin.ModelAdmin):
    list_display = ('user', 'status','created_date')
# Associate the custom admin class with the model
admin.site.register(TotalRequest, TotalRequestAdmin)


