from django.urls import path
from rules.views import variables, update_variables,sponsor_rules,update_rules, scorecard, update_cutoffval,newairpakapi,search_request,firstuepaapi, seconduepaapi, thirduepaapi

urlpatterns = [
    path('variables/', variables, name='variables'),
    path('update_variables/', update_variables, name='updatevariables'),
    path('sponsor_rules/', sponsor_rules, name='sponsorrules'),
    path('update_rules/', update_rules, name='updaterules'),
    path('scorecard/', scorecard, name='scorecard'),
    #path('airpakapi/', airpakapi, name='airpakapi'),
    path('newairpakapi/', newairpakapi, name='newairpakapi'),
    
    path('update_cutoffval/', update_cutoffval, name='update_cutoffval'),
    path('searchrequest/', search_request, name='searchrequest'),
    path('firstuepaapi/', firstuepaapi, name='firstuepaapi'),
    path('seconduepaapi/', seconduepaapi, name='seconduepaapi'),
    path('thirduepaapi/', thirduepaapi, name='thirduepaapi'),   
    
]