from django.core.management.base import BaseCommand
from django.utils import timezone
from django.contrib.auth import get_user_model
User = get_user_model()

class Command(BaseCommand):
    help = 'Create superuser and normal user with specified details'

    def handle(self, *args, **options):
        # Create superuser
        User.objects.create_superuser(
            first_name='vikram',
            last_name='kumar',
            email='vikram.kumar@systematixindia.com',
            password='Sipl@1234',
        )

        self.stdout.write(self.style.SUCCESS('Superuser created successfully'))

        # Create normal user
        User.objects.create_user(
            first_name='vicky',
            last_name='kumar',
            email='vicky@yopmail.com',
            password='Sipl@1234',
        )

        self.stdout.write(self.style.SUCCESS('Normal user created successfully'))
