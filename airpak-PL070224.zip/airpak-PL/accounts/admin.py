from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth import get_user_model
from accounts.models import UserBasicDetails
from django.utils.html import format_html
from django.utils.safestring import mark_safe

User = get_user_model()

@admin.register(UserBasicDetails)
class UserBasicDetailsAdmin(admin.ModelAdmin):
    list_display = ('user', 'gender', 'date_of_birth', 'image_tag', 'phone_number')
    list_display_links = ('user',)
    search_fields = ('user__email', 'user__first_name', 'user__last_name')

    def get_ordering(self, request):
        return ['user__email']

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'user':
            kwargs['widget'] = UserWithImageWidget(db_field.remote_field, self.admin_site)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    def image_tag(self, obj):
        if obj.profile_image:
            return format_html('<img src="{}" style="width: 45px; height: 45px; border-radius: 50%;" />'.format(obj.profile_image.url))
        else:
            return 'No Image Found'

    image_tag.short_description = 'Image'

class UserWithImageWidget(admin.widgets.ForeignKeyRawIdWidget):
    def render(self, name, value, attrs=None, renderer=None):
        output = super().render(name, value, attrs, renderer)
        try:
            instance = self.rel.model._default_manager.get(pk=value)
            if instance.userBasicDetails.profile_image:
                output += format_html(
                    '<br><img src="{}" style="max-width: 200px; max-height: 200px; border-radius: 4px; margin-top: 5px;" />',
                    instance.userBasicDetails.profile_image.url
                )
        except self.rel.model.DoesNotExist:
            pass
        return output

    class Media:
        js = ('admin/js/jquery.init.js', 'admin/js/user_with_image_widget.js',)
        
@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    """Define admin model for custom User model with no email field."""

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        (('Personal info'), {'fields': ('first_name', 'last_name')}),
        (('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        (('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2'),
        }),
    )
    list_display = ('email', 'first_name', 'last_name', 'is_staff')
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)
