from pathlib import Path
import os

from dotenv import load_dotenv
load_dotenv()

# Determine the current environment ('development', 'production', etc.)
ENVIRONMENT = os.getenv('DJANGO_ENV', 'development')

# Import the appropriate settings based on the environment
if ENVIRONMENT == 'production':
    from config.production import *
if ENVIRONMENT == 'development':
    from config.development import *

# # Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# # SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('SECRET_KEY', 'django-insecure-^-b4-%%gy@cq1nj3(!nhb$(^)9-61ah#+ej!s$@7fm&f06s^%v')
# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Application definition
DEFAULT_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rules',
]

LOCAL_APPS = [
    'accounts.apps.AccountsConfig', # Account Application
]

THIRDPARTY_APPS = [
    'rest_framework',
    'rest_framework.authtoken',
]

INSTALLED_APPS = DEFAULT_APPS + LOCAL_APPS + THIRDPARTY_APPS  # + ['INSTALLED_APPS']

DEFAULT_MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    "corsheaders.middleware.CorsMiddleware",
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

THIRDPARTY__MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
]

MIDDLEWARE = DEFAULT_MIDDLEWARE + THIRDPARTY__MIDDLEWARE

ROOT_URLCONF = 'PL_Credit_Engine_Static.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'PL_Credit_Engine_Static.wsgi.application'

# Password validation
# https://docs.djangoproject.com/en/4.2/ref/settings/#auth-password-validators
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/4.2/topics/i18n/

LANGUAGES = [
    ('en', 'English'),
    ('es', 'Español'),
    ('fr', 'Français'),
    ('tr', 'Türkçe'),
]

# Set the default language
LANGUAGE_CODE = 'en'

LOCALE_PATHS = [
    os.path.join(BASE_DIR, 'locale'),  # Replace <app_name> with the actual name of your app
]


TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.2/howto/static-files/
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'static_root')
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static'),]

# Media files (Uploaded files)
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Default primary key field type
# https://docs.djangoproject.com/en/4.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

AUTH_USER_MODEL = 'accounts.User'

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ], 'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.TokenAuthentication',
        'rest_framework.authentication.BasicAuthentication',
        'rest_framework.authentication.SessionAuthentication',

    ), 'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
    ), 'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',

}

# Email settings
DEFAULT_EMAIL_FROM = os.getenv('DEFAULT_EMAIL_FROM', 'Credit Engine Static <sipltest49@gmail.com>')
DEFAULT_EMAIL_BCC = os.getenv('DEFAULT_EMAIL_BCC', 'aashish.soni@systematixindia.com')
EMAIL_HOST = os.getenv('EMAIL_HOST', 'smtp.googlemail.com')
EMAIL_PORT = int(os.getenv('EMAIL_PORT', 465))
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER', 'sipltest49@gmail.com')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD', 'pcigzugryisujifp')
EMAIL_USE_TLS = os.getenv('EMAIL_USE_TLS', 'False').lower() == 'true'
EMAIL_USE_SSL = os.getenv('EMAIL_USE_SSL', 'True').lower() == 'true'
SERVER_EMAIL = os.getenv('SERVER_EMAIL', 'sipltest49@gmail.com')


# Configure session-related settings
# Example settings; customize them according to your needs
SESSION_ENGINE = 'django.contrib.sessions.backends.db'  # Database-backed sessions
SESSION_COOKIE_AGE = 18000000  # Session cookie age in seconds (30 minutes)
SESSION_COOKIE_NAME = 'my_session'  # Session cookie name
SESSION_EXPIRE_AT_BROWSER_CLOSE = False  # Session does not expire on browser close
SESSION_COOKIE_SECURE = False  # Use secure session cookies (requires HTTPS)
SESSION_COOKIE_HTTPONLY = True  # Restrict session cookies from client-side JavaScript
SESSION_SAVE_EVERY_REQUEST = True
SITE_ID = 1


CORS_ORIGIN_WHITELIST = [
    'https://plcreditenginestatic.siplsolutions.com',
    # Add any other trusted origins if necessary
]

CORS_ORIGIN_ALLOW_ALL = True

CSRF_TRUSTED_ORIGINS = [
    'https://plcreditenginestatic.siplsolutions.com',
    ]

CORS_ALLOWED_ORIGINS = [
    'https://plcreditenginestatic.siplsolutions.com',
]

