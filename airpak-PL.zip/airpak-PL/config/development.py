# config/development.py

# Import the common settings from base.py
from .base import *

# Add environment-specific settings
DEBUG = True
ALLOWED_HOSTS = ["*"]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'airpak',
        'USER': 'admin123',
        'PASSWORD': 'Anil@123',
        'HOST': 'airpakdb.postgres.database.azure.com',
        'PORT': '5432',
    }
}
# ...

CORS_ORIGIN_WHITELIST = [
    'https://airpak.azurewebsites.net',
    # Add any other trusted origins if necessary
]

CORS_ORIGIN_ALLOW_ALL = True

CSRF_TRUSTED_ORIGINS = [
    'http://localhost:8000',
    'https://airpak.azurewebsites.net',
    ]

CORS_ALLOWED_ORIGINS = [
    'http://localhost:8000',
    'https://airpak.azurewebsites.net',
]
