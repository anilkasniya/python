"""
URL configuration for PL_Credit_Engine_Static_Developers' accounts application.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# resend_code

from django.urls import path, include
from accounts.views import home, forget_password, set_password_view, login_view, signout, change_password, edit_profile

urlpatterns = [
    path('', login_view, name='sign_in'),
    path('dashboard/', home, name='dashboard'),
    path('forget_password/', forget_password, name='forget_password'),
    path('set_password/<str:uidb64>/<str:token>/', set_password_view, name='set_password'),
    path("signout/", signout, name="signout"),
    path('change_password/', change_password, name='change_password'),
    path('edit_profile/', edit_profile, name='edit_profile'),
    path('rules/', include('rules.urls')),
]