from django.shortcuts import render, redirect
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth import get_user_model, logout, update_session_auth_hash, login
from django.contrib.auth.hashers import make_password
from django.contrib.auth.backends import ModelBackend
from django.contrib import messages
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.template.loader import render_to_string
from django.conf import settings
from django.urls import reverse
from django.contrib.auth.decorators import login_required
# from django.views.decorators.cache import never_cache
import re
from django.contrib.auth.hashers import check_password
from django.core.mail import send_mail
from django.utils.html import strip_tags
from accounts.models import UserBasicDetails, CommonPassword
from datetime import datetime, timedelta, date
from django.utils import timezone
from django.contrib.auth import authenticate
from django.core.cache import cache
MAX_LOGIN_ATTEMPTS = 5  # Maximum number of allowed login attempts
LOCKOUT_DURATION = 300  # Lockout duration in seconds (5 minutes)
User = get_user_model()
from rules.models import TotalRequest
# Create your views here.

@login_required(login_url='')
# @never_cache
def home(request):
    userid = [1,2,6]
    totalreject = TotalRequest.objects.filter(user_id__in=userid,status="rejected").count()
    totalapproved = TotalRequest.objects.filter(user_id__in=userid,status="approved").count()
    totalcount = TotalRequest.objects.filter(user_id__in=userid).exclude(status="pending").count()
    
    return render(request, 'dashboard/dashboard.html', {"totalreject" : totalreject,"totalapproved" : totalapproved,"totalcount" : totalcount})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        email = request.POST.get('email', '').strip().lower()
        password = request.POST.get('password', '').strip()
        # Check if the user is temporarily locked out
        lockout_key = f'lockout_{email}'
        if cache.get(lockout_key):
            messages.error(request, 'You are temporarily locked. Please try again after 5 min.')
            return redirect(login_view)
        user = authenticate(request, email=email, password=password)
        if user is not None:
            if user.is_active:
                if is_user_inactive(user):
                    # Deactivate the user's account
                    user.is_active = False
                    user.save()
                    messages.error(request, 'Your account has been deactivated due to inactivity.')
                    return redirect(login_view)
                # Access the session object
                user_session = request.session
                # You can access and modify session attributes
                user_session['first_name'] = user.first_name
                user_session['last_name'] = user.last_name
                user_session['email'] = user.email
                user_session['password'] = password
                user_session['mobile'] = "+919939822211"
                user = authenticate(request, email=request.session.get('email'), password=request.session.get('password'))
                login(request, user)
                # Check if it's the user's first login or joining date is greater than 90 days
                if user.last_login is None or (user.date_joined + timedelta(days=90)) < timezone.now():
                    # Redirect to change password view
                    return redirect(change_password)
                return redirect(home)
            else:
                messages.error(request, 'Your account is deactivated.')
                return redirect(login_view)
        else:
            handle_login_attempt(request, email)
            if request.session.get('max_login_attempts_reached'):
                messages.error(request, 'You have reached the maximum number of login attempts. Please try again after 5 min.')
                del request.session['max_login_attempts_reached']
            elif not email:
                messages.error(request, 'Please enter email address and password')
            else:
                messages.error(request, 'Please enter a valid email address and password')
    return render(request, 'accounts/login.html')

def is_user_inactive(user):
    join_date = user.join_date.date()
    current_date = date.today()
    days_since_joining = (current_date - join_date).days
    return days_since_joining > 120

def handle_login_attempt(request, email):
    login_attempts_key = f'login_attempts_{email}'
    login_attempts = cache.get(login_attempts_key, 0) + 1
    cache.set(login_attempts_key, login_attempts, LOCKOUT_DURATION)
    if login_attempts >= MAX_LOGIN_ATTEMPTS:
        lockout_key = f'lockout_{email}'
        cache.set(lockout_key, True, LOCKOUT_DURATION)
        request.session['max_login_attempts_reached'] = True

def change_password(request):
    if request.method == 'POST':
        current_password = request.POST.get('current_password').strip()
        new_password = request.POST.get('new_password').strip()
        confirm_password = request.POST.get('confirm_password').strip()
        user = request.user
        if user.is_anonymous:
            try:
                user = User.objects.get(email=request.session.get('email'))
            except:
                messages.error(request, 'User does not exist.')
                return redirect(login_view)
        if not current_password:
            messages.error(request, 'Please enter the current password.')
        elif not new_password and not confirm_password:
            messages.error(request, 'Please enter the new password.')
        elif not user.check_password(current_password):
            messages.error(request, 'Invalid current password.')
        elif new_password == current_password:
            messages.warning(request, 'You have entered a password that you have used before. Please choose a different one.')
        else:
            common_passwords = CommonPassword.objects.filter(user=user)
            if any(check_password(new_password, common_password.password) for common_password in common_passwords):
                messages.warning(request, 'You have entered a password that you have used before. Please choose a different one.')
            else:
                if new_password == confirm_password:
                    # Save the current password as a previous password
                    CommonPassword.objects.create(user=user, password=make_password(current_password))
                    # Update the user's join date and password
                    user.date_joined = timezone.now()
                    user.set_password(new_password)
                    user.save()
                    if not request.user.is_authenticated:
                        # User is not logged in, so authenticate and login
                        user = authenticate(request, email=request.session.get('email'), password=new_password)
                        login(request, user)
                        return redirect(home)
                    else:
                        # User is already logged in, update the session auth hash
                        update_session_auth_hash(request, user)
                        return redirect(home)
                else:
                    messages.error(request, 'New passwords do not match.')
    return render(request, 'accounts/change_password.html')

def forget_password(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        email = request.POST.get('email').strip().lower()
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, 'Please enter a valid email address')
            return redirect(forget_password)

        # Generate a password reset token and construct the reset URL
        token = default_token_generator.make_token(user)
        current_site = get_current_site(request)
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))

        # Set the reset URL based on the environment
        reset_url = ''
        if settings.ENVIRONMENT == 'production':
            reset_url = f"https://plcreditenginestatic.siplsolutions.com/set_password/{uidb64}/{token}/"
        elif settings.ENVIRONMENT == 'development':
            reset_url = f"http://localhost:8000/set_password/{uidb64}/{token}/"

        # Set the expiration time for the reset link (5 minutes from now)
        expiration_time = timezone.now() + timedelta(minutes=5)
        user.expiry_date = expiration_time
        user.save()
        subject = 'Reset your password'
        mail_body = render_to_string('accounts/email/reset_password_email.html', {
            'user': user,
            'reset_url': reset_url,
            'logo': 'http://plcreditenginestatic.siplsolutions.com/static/logo.png',
            'expiration_time': expiration_time,
        })

        # Send the password reset email to the user's email address
        send_mail(subject, '', settings.DEFAULT_EMAIL_FROM, [email], html_message=mail_body)
        # send_mail(subject, '', settings.EMAIL_HOST_USER, [email], html_message=mail_body)
        messages.success(request, 'A password reset link has been sent to your email address. Please check your email. The link is valid for 5 minutes.')
        return redirect(login_view)
    
    return render(request, 'accounts/email/forget_password.html')

def set_password_view(request, uidb64, token):
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = User.objects.get(pk=uid)                
        # Check if the password reset link has expired
        if user.expiry_date and user.expiry_date < timezone.now():
            messages.error(request, 'The password reset link has expired. Please request a new one.')
            return redirect(login_view)
        
        if default_token_generator.check_token(user, token):
            if request.method == 'POST':
                new_password = request.POST.get('new_password').strip()
                confirm_password = request.POST.get('confirm_password').strip()
                common_passwords = CommonPassword.objects.filter(user=user)
                # Validate the new password and confirm password fields
                
                CommonPassword.objects.create(user=user, password=make_password(user.password))
                # Update the user's password
                user.set_password(new_password)
                user.save()
                # Display a success message
                messages.success(request, 'Your password has been reset successfully.')
                return redirect('/')  # Replace 'home' with the appropriate URL name for the home page
            
            return render(request, 'accounts/set_password.html', {'uidb64': uidb64, 'token': token})
        else:
            # Display an error message if the token is invalid or expired
            messages.error(request, 'Invalid or expired token. Please request a new password reset.')
            return redirect(login_view)  # Redirect to the login page
    except User.DoesNotExist:
        # Display an error message if the user does not exist
        messages.error(request, 'User does not exist.')
        return redirect(login_view)  # Redirect to the login page
    
def check_common_passwords(new_password, user):
    common_passwords = CommonPassword.objects.filter(user=user)
    return any(check_password(new_password, common_password.password) for common_password in common_passwords)
    
def is_password_strong(password):
    # Implement the password strength requirements
    if len(password) < 12:
        return False
    if not re.search(r'\d', password):
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'[@#$%^&+=*!]', password):
        return False
    return True

def edit_profile(request):
    # Fetch the current user's profile details
    user_details = UserBasicDetails.objects.get(user=request.user)
    user = user_details.user  # Get the related User model
    if request.method == 'POST':
        # Update the profile attributes based on the submitted form data
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user_details.gender = request.POST.get('gender')
        user_details.phone_number = request.POST.get('phone_number')
        user_details.date_of_birth = request.POST.get('date_of_birth')
        profile_image = request.FILES.get('profile_image')
        if profile_image:
            user_details.profile_image = profile_image
        user.save()  # Save the User model
        user_details.save()  # Save the UserBasicDetails model
        # return HttpResponse("Successfully updated")
        return redirect(home)
    context = {'user_details': user_details}
    return render(request, 'accounts/edit_profile.html', context)

def signout(request):
    # Additional actions before logout (if needed)
    logout(request)
    return redirect(reverse(login_view))
