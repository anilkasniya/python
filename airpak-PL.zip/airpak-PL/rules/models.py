from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
User = get_user_model()
def get_current_datetime():
    return timezone.now()

# Create your models here.

class DictionaryVariable(models.Model):
    # ForeignKey relationship to the User model with a related_name of "user_dictionary_variable"
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_dictionary_variable")
    # ForeignKey relationship to the VariableType model with a related_name of "dictionary_variables"
    variable_type = models.CharField(max_length=255, null=False, blank=False)  
    # CharField to store the variable name
    variable_display_name = models.CharField(max_length=255, null=True, blank=True)
    variable_name = models.CharField(max_length=255, null=False, blank=False)
    variable_source = models.CharField(max_length=255, null=False, blank=False)
    variable_rule = models.CharField(max_length=255, null=True, blank=True)
    variable_value = models.CharField(max_length=255, null=False, blank=False)
    # ForeignKey relationship to the VariableFormat model with a related_name of "dictionary_variables"
    variable_required = models.BooleanField(default=True)
    description = models.TextField(null=True, blank=True)
    created_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.variable_name
    

class VariableScorecard(models.Model):
    # ForeignKey relationship to the User model with a related_name of "user_dictionary_variable"
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_variable_rules")
    variable_display_name = models.CharField(max_length=255, null=True, blank=True)
    variable_name = models.CharField(max_length=255, null=False, blank=False)
    bucket_number = models.IntegerField(null=False, blank=False)
    bucket_label = models.CharField(max_length=255, null=False, blank=False)
    min_val = models.DecimalField(max_digits=10, decimal_places=2)
    max_val = models.DecimalField(max_digits=10, decimal_places=2)
    score = models.DecimalField(max_digits=10, decimal_places=2) #points
    created_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.variable_name
    
class ApiResonse(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_dictionary_response")
    response = models.JSONField()
    created_date = models.DateTimeField(default=timezone.now)


class TotalRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sponsor_request")
    status = models.CharField(max_length=10, null=True, blank=True)
    created_date = models.DateTimeField(default=timezone.now)
    